﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;
using System.Web.Mvc;

//namespace RMSTest.Functions
//{
//    public class AuthenticationFilter : System.Web.Mvc.ActionFilterAttribute
//    {
//        public override void OnActionExecuting(ActionExecutingContext filterContext)
//        {
           
//            string username = filterContext.HttpContext.Request.Params["username"];
//            string password = filterContext.HttpContext.Request.Params["password"];

//            string connectionString = "server=localhost; Database = RMS; User Id = sa; Password = password@1;";
//            using (SqlConnection conn = new SqlConnection(connectionString))
//            {
//                conn.Open();

//                using (SqlCommand cmd = new SqlCommand("T_SP_CHECKLOGIN", conn))
//                {
//                    cmd.CommandType = CommandType.StoredProcedure;

//                    cmd.Parameters.AddWithValue("@P0", username);
//                    cmd.Parameters.AddWithValue("@P1", password);

//                    SqlParameter validParam = new SqlParameter("@OutputParam", SqlDbType.Bit);
//                    validParam.Direction = ParameterDirection.Output;
//                    cmd.Parameters.Add(validParam);

//                    cmd.ExecuteNonQuery();

//                    bool valid = (bool)validParam.Value;

//                    if (!valid)
//                    {
                        
//                        filterContext.Result = new RedirectResult("/login");
//                    }
//                }
//            }
//        }
//    }
//}