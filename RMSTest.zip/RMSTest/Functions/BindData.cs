﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using RMSTest.Functions;
using static RMSTest.Functions.Credentials;

namespace RMSTest.Functions
{
  
  


    public class CheckLogin
    {
        
        string connectionString = ConnectionStringdb.CName;

        public string LoginCheck(Credentials cd)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("T_SP_CHECKLOGIN", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@P0", cd.Admin_id);
                cmd.Parameters.AddWithValue("@P1", cd.Ad_Password);
                var outParam = new SqlParameter("@OutputParam", SqlDbType.VarChar, 150);
                outParam.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam);
                con.Open();
                cmd.ExecuteNonQuery();
                string res = (cmd.Parameters["@OutputParam"].Value.ToString());
                con.Close();
                return res;
                

            }
        }

    }

    public class DivisionBind
    {
        string connectionString = ConnectionStringdb.CName;
            


    } 


    public class CircleBind
    {



    }

    public class EmpTypeBind
    {



    }

    public class EmpBind
    {



    }



}