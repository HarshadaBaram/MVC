﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class KRAController : Controller
    {
     
        public ActionResult Set_KRA()
        {
            return View();
        }


        public ActionResult Import_KRA()
        {
            return View();
        }

        public ActionResult Role_KRA_Mapping()
        {
            return View();
        }


        public ActionResult Status_Summary_Report()
        {
            return View();
        }


        public ActionResult KRA_Detailed_Report()
        {
            return View();
        }

        public ActionResult Training_Report()
        {
            return View();
        }

        public ActionResult Summary_training_Report()
        {
            return View();

        }


        public ActionResult Detailed_Report_Reviewed()
        {
            return View();
        }


        public ActionResult Detailed_Report_For_Resigned_Employees()
        {
            return View();
        }


        public ActionResult KPI_Detailed_Report()
        {
            return View();
        }


        public ActionResult KPI_Summary_Report()
        {
            return View();
        }


        public ActionResult KRA_Competancies_Detailed_Report()
        {
            return View();
        }


    }
}
