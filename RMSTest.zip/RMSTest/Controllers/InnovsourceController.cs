﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class InnovsourceController : Controller
    {
       
        public ActionResult Add_Resource()
        {
            return View();
        }


        public ActionResult Search_Resource()
        {
            return View();
        }

        public ActionResult Resignation_Module()
        {
            return View();
        }

        public ActionResult Deployment_Report()
        {
            return View();
        }

        public ActionResult Attendance()
        {
            return View();
        }

        public ActionResult View_Attendance()
        {
            return View();
        }

        public ActionResult Employee_Attendance()
        {
            return View();
        }

        public ActionResult Attendance_Summary()
        {
            return View();
        }

        public ActionResult Detailed_Report()
        {
            return View();
        }




    }
}
