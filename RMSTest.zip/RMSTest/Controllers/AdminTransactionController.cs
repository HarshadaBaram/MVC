﻿using RMSTest.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class AdminTransactionController : Controller
    {
        string db = ConnectionStringdb.CName;

        public ActionResult Hierarchy_Role_Mapping()
        {
            {
                List<SelectListItem> Module = new List<SelectListItem>();

                using (SqlConnection connection = new SqlConnection(db))
                {
                    using (SqlCommand command = new SqlCommand("T_SP_GET_MODULE_NAME_FOR_BIND", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        //command.Parameters.Add(new SqlParameter("@P0", 1));
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Module.Add(new SelectListItem
                                {
                                    Text = reader["T_MODULE_NAME"].ToString(),
                                    Value = reader["T_MODULE_ID"].ToString()
                                });
                            }
                        }
                    }
                }

                ViewBag.Module = Module;

            }
            return View();
        
           
        }

        public ActionResult Hierarchy_Role_Employee_Mapping()
        {
            {
                List<SelectListItem> Module = new List<SelectListItem>();

                using (SqlConnection connection = new SqlConnection(db))
                {
                    using (SqlCommand command = new SqlCommand("T_SP_GET_MODULE_NAME_FOR_BIND", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        //command.Parameters.Add(new SqlParameter("@P0", 1));
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Module.Add(new SelectListItem
                                {
                                    Text = reader["T_MODULE_NAME"].ToString(),
                                    Value = reader["T_MODULE_ID"].ToString()
                                });
                            }
                        }
                    }
                }

                ViewBag.Module = Module;

            }



           
            return View();


        }

        public ActionResult Admin_Attendance_Updation()
        {
            return View();
        }

        public ActionResult Admin_Arrear_Updation()
        {
            return View();
        }

         public ActionResult Admin_MRF_Update()
        {
            return View();
        }

        public ActionResult Delete_MRF()
        {
            return View();
        }

        public ActionResult Division_Role_Grade_Mapping()
        {
            return View();
        }

        public ActionResult Division_Costcode_Department_Mapping()
        {
            return View();
        }

        public ActionResult Upload_Supporting_Documents_Admin()
        {
            return View();
        }

        public ActionResult Admin_Candidate_Edit()
        {
            return View();
        }

        public ActionResult Pull_Data_From_Adrenalin()
        {
            return View();
        }

        public ActionResult Update_KRA_Status()
        {
            return View();
        }

        public ActionResult Delete_FNF_Details()
        {
            return View();
        }

        public ActionResult Admin_Arrear_Updation_New()
        {
            return View();
        }

    }
}
