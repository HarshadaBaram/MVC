﻿using RMSTest.Functions;
using RMSTest.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using System.Web.Security;

namespace RMSTest.Controllers
{
    public class HomeController : Controller
    {
        string db = ConnectionStringdb.CName;
        public ActionResult Login()
        {

            return View();

        }

        [HttpPost]
        public ActionResult Login([Bind] T_EMPLOYEE_MSTR Login)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(db))
                {
                    SqlCommand cmd = new SqlCommand("T_SP_CHECKLOGIN", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    string name = Request["Admin_id"];
                    string pass = Request["Ad_Password"];
                    cmd.Parameters.AddWithValue("@P0", Login.T_EMP_NO);
                    cmd.Parameters.AddWithValue("@P1", Login.T_EMP_PASSWORD);
                    var outParam = new SqlParameter("@OutputParam", SqlDbType.VarChar, 150);
                    outParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(outParam);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    string res = (cmd.Parameters["@OutputParam"].Value.ToString());
                    con.Close();
                    TempData["msg"] = res;

                    if (res == "Successfull Login")
                    {
                        return RedirectToAction("Index", "Home");
                    }

                }
            }

          
            return View();
          
        }





        public ActionResult Index()
        {

            return View();

        }





        public ActionResult Forget_Password()
        {

            return View();

        }


      






    }
}






