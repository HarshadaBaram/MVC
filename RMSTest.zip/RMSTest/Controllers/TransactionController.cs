﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class TransactionController : Controller
    {
        
        public ActionResult Request_List_For_Release()
        {
            return View();
        }

        public ActionResult Release_Resource()
        {
            return View();
        }

        public ActionResult Timesheet()
        {
            return View();
        }

        public ActionResult Preview_TimeSheet()
        {
            return View();
        }

        public ActionResult Approve_TimeSheet()
        {
            return View();
        }

        public ActionResult Create_New_Logins()
        {
            return View();
        }

        public ActionResult Add_Resource()
        {
            return View();
        }

        public ActionResult Travel_Request_Form()
        {
            return View();
        }

        public ActionResult Approve_Travel_Request()
        {
            return View();
        }

        public ActionResult Budgetory_Approval()
        {
            return View();
        }

        public ActionResult Upload_Supporting_Documents()
        {
            return View();
        }

        public ActionResult Update_Employee_Details()
        {
            return View();
        }

        public ActionResult Employee_Transfer_Form()
        {
            return View();
        }

        public ActionResult Approve_Transfer_Form()
        {
            return View();
        }

        public ActionResult Generate_Transfer_Form()
        {
            return View();
        }

        public ActionResult Import_Shift()
        {
            return View();
        }

        public ActionResult Update_Reporting_Manager()
        {
            return View();
        }

        public ActionResult Swipe_card_Mapping()
        {
            return View();
        }

        public ActionResult Appraisal_Review()
        {
            return View();
        }

        public ActionResult Warnings()
        {
            return View();
        }

        public ActionResult Rewards()
        {
            return View();
        }

        public ActionResult Generate_Letters()
        {
            return View();
        }

        public ActionResult Foundation_Donation_Import()
        {
            return View();
        }

        public ActionResult Foundation_Donation_Receipt()
        {
            return View();
        }

        public ActionResult Employee_Details_Verification()
        {
            return View();
        }

        public ActionResult Bus_Late_In_Update()
        {
            return View();
        }

        public ActionResult Reimbursement_Account_Confirmation()
        {
            return View();
        }

        public ActionResult Reimbursement_Acknowledgement()
        {
            return View();
        }

        public ActionResult Replicate_Project_Role_For_New_FY()
        {
            return View();
        }

        public ActionResult Update_Last_Working_Date_HR()
        {
            return View();
        }

        public ActionResult Queries_To_Initiator()
        {
            return View();
        }



    }
}
