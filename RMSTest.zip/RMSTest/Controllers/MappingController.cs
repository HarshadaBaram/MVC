﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class MappingController : Controller
    {
        
        public ActionResult Division_User()
        {
            return View();
        }

        public ActionResult User_Employee_Type()
        {
            return View();
        }

        public ActionResult Adrenalin_Department()
        {
            return View();
        }

        public ActionResult Workflow_Employee_Division()
        {
            return View();
        }

        public ActionResult Workflow_Employee_Circle()
        {
            return View();
        }

        public ActionResult User_Form()
        {
            return View();
        }

        public ActionResult Division_Cost_Code()
        {
            return View();
        }

        public ActionResult Workflow_Employee_Department()
        {
            return View();
        }

        public ActionResult Workflow_Employee_Type()
        {
            return View();
        }

        public ActionResult Department_HOD()
        {
            return View();
        }

        public ActionResult KRA_Role()
        {
            return View();
        }

        public ActionResult Shift()
        {
            return View();
        }

        public ActionResult Role_Grade()
        {
            return View();
        }

        public ActionResult Role_CTC()
        {
            return View();
        }

        public ActionResult Role_Qualification()
        {
            return View();
        }

        public ActionResult Role_Experience()
        {
            return View();
        }

        public ActionResult Role_KRA()
        {
            return View();
        }

        public ActionResult Tool_Kit()
        {
            return View();
        }

        public ActionResult Replicate_Project_Role_For_New_FY()
        {
            return View();
        }

        public ActionResult Role_Competancy()
        {
            return View();
        }

        public ActionResult Employee_Competancy()
        {
            return View();
        }

    }
}
