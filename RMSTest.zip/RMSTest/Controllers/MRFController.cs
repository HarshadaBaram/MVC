﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class MRFController : Controller
    {
      
        public ActionResult Initiate_MRF_Approval()
        {
            return View();
        }

        public ActionResult MRF_Pending_For_Approval()
        {
            return View();
        }


        public ActionResult Edit_MRF_Details_Admin()
        {
            return View();
        }


        public ActionResult Raise_New_MRF()
        {
            return View();
        }

        public ActionResult Raise_MRF_Full()
        {
            return View();
        }


        public ActionResult Change_External_Candidate()
        {
            return View();
        }


        public ActionResult MRF_Complete_Details()
        {
            return View();
        }

        public ActionResult MRF_Closure_Report()
        {
            return View();
        }

        public ActionResult MRF_Cancellation_Report()
        {
            return View();
        }

    }
}
