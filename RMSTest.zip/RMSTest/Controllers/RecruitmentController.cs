﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class RecruitmentController : Controller
    {
       
        public ActionResult Canditate_Pending_For_Approval()
        {
            return View();
        }

        public ActionResult Update_Employee_ID_After_Offer_Generation()
        {
            return View();
        }

        public ActionResult Update_Reporting_Date_At_Innovsource()
        {
            return View();
        }

        public ActionResult Update_Joining_Formalities_GTL()
        {
            return View();
        }

        public ActionResult Assign_Candidate_To_MRF()
        {
            return View();
        }

        public ActionResult Update_Offer_Details_Admin()
        {
            return View();
        }

        

    }
}
