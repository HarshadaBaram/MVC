﻿using RMSTest.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class SettingController : Controller
    {
        string db = ConnectionStringdb.CName;

        public ActionResult Change_Password()
        {
            return View();
        }


        public ActionResult Reset_Password()
        {

            {
                List<SelectListItem> UserName = new List<SelectListItem>();

                using (SqlConnection connection = new SqlConnection(db))
                {
                    using (SqlCommand command = new SqlCommand("T_SP_GET_USER_FOR_DDL", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@P0", 1));
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                UserName.Add(new SelectListItem
                                {
                                    Text = reader["T_USER_NAME"].ToString(),
                                    Value = reader["T_USER_ID"].ToString()
                                });
                            }
                        }
                    }
                }

                ViewBag.UserName = UserName;

            }
            return View();
        }

        public ActionResult Get_Password()
        {
            return View();
        }

        public ActionResult Admin_Reset_Password()
        {
            return View();
        }

     
    }
}
