﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class AssignController : Controller
    {
      
        public ActionResult Streams_To_Domain()
        {
            return View();
        }

        public ActionResult Highest_Degree_To_Qualification()
        {
            return View();
        }

        public ActionResult Rights_To_Role()
        {
            return View();
        }

        public ActionResult Circle_To_User()
        {
            return View();
        }


        public ActionResult Division_Codes()
        {
            return View();
        }

        public ActionResult Projects_To_Circle()
        {
            return View();
        }

        public ActionResult Project_Code()
        {
            return View();
        }

        public ActionResult Project_To_User()
        {
            return View();
        }

        public ActionResult Project_To_Multiple_User()
        {
            return View();
        }

        public ActionResult Project_Manager()
        {
            return View();
        }

        public ActionResult New_Budget()
        {
            return View();
        }

        public ActionResult Budget_Approval()
        {
            return View();
        }

        public ActionResult Upload_Budget()
        {
            return View();
        }

    }
}
