﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class AttendanceController : Controller
    {
       
        public ActionResult Attendance_Check()
        {
            string connectionString = "server=localhost; Database = RMS; User Id = sa; Password = password@1;";


            {
                List<SelectListItem> Division = new List<SelectListItem>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("T_SP_GET_DIVISION_FOR_ATTENDANCE", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@P0", 1));
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Division.Add(new SelectListItem
                                {
                                    Text = reader["T_DIVISION_NAME"].ToString(),
                                    Value = reader["T_DIVISION_ID"].ToString()
                                });
                            }
                        }
                    }
                }

                ViewBag.Division = Division;
               
            }


            {
                List<SelectListItem> Circle = new List<SelectListItem>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("T_SP_GET_CIRCLE_FOR_ATTENDANCE", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@P0", 1));
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Circle.Add(new SelectListItem
                                {
                                    Text = reader["T_CIRCLE_NAME"].ToString(),
                                    Value = reader["T_CIRCLE_ID"].ToString()
                                });
                            }
                        }
                    }
                }

                ViewBag.Circle = Circle;

            }



            //{
            //    List<SelectListItem> EmpType = new List<SelectListItem>();

            //    using (SqlConnection connection = new SqlConnection(connectionString))
            //    {
            //        using (SqlCommand command = new SqlCommand("T_SP_GET_EMPLOYEE_TYPE_FOR_ATTENDANCE_NEW", connection))
            //        {
            //            command.CommandType = CommandType.StoredProcedure;
            //            command.Parameters.Add(new SqlParameter("@P0", 1));
                        
            //            connection.Open();

            //            using (SqlDataReader reader = command.ExecuteReader())
            //            {
            //                while (reader.Read())
            //                {
            //                    EmpType.Add(new SelectListItem
            //                    {
            //                        Text = reader["T_TYPE_NAME"].ToString(),
            //                        Value = reader["T_TYPE_ID"].ToString()
            //                    });
            //                }
            //            }
            //        }
            //    }

            //    ViewBag.EmpType = EmpType;

            //}

            return View();



        }


        public ActionResult Deactivate_Forms()
        {

            { 
                return View();
            }

        }


        public ActionResult Attendance_Freeze()
        {
            return View();
        }


        public ActionResult Update_Resigned_and_NJ_Status()
        {
            return View();
        }


        public ActionResult Update_Leave_for_Arrears()
        {
            return View();
        }

        public ActionResult Update_Andrenaline_Freezed_Date()
        {
            return View();
        }


        public ActionResult Forms_Activation()
        {
            return View();
        }

        public ActionResult Leave_Request()
        {
            return View();
        }

        public ActionResult Approve_Leave_Request()
        {
            return View();
        }

        public ActionResult Approve_Reject_Attendance()
        {
            return View();
        }

        public ActionResult Leave_Cancellation()
        {
            return View();
        }

        public ActionResult Cancel_Leave_Approval()
        {
            return View();
        }

        public ActionResult Import_Attendance()
        {
            return View();
        }

        public ActionResult Attendance_Regularization()
        {
            return View();
        }

        public ActionResult Attendance_Regularization_Approval()
        {
            return View();
        }

        public ActionResult Attendance_Freezing()
        {
            return View();
        }

        public ActionResult Sync_Attendance()
        {
            return View();
        }

        public ActionResult Admin_Attendance_Regularization()
        {
            return View();
        }

        public ActionResult Attendance_Innovsource()
        {
            return View();
        }

        public ActionResult Leave_Regularization()
        {
            return View();
        }

        public ActionResult Attendance_Security_GIL()
        {
            return View();
        }

       


        public ActionResult View_Attendance()
        {
            return View();
        }

        public ActionResult Paid_Holidays()
        {
            return View();
        }


        public ActionResult HR_Reports()
        {
            return View();
        }

    }
}
