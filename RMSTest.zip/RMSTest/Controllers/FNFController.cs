﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class FNFController : Controller
    {
        
        public ActionResult Initiate_FNF()
        {
            return View();
        }


        public ActionResult Employee_Exit()
        {
            return View();
        }

        public ActionResult Employee_Exit_Details()
        {
            return View();
        }

        public ActionResult HOD_Clearance()
        {
            return View();
        }

        public ActionResult Local_Admin_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_Admin_Clearance()
        {
            return View();
        }

        public ActionResult Local_IT_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_IT_Clearance()
        {
            return View();
        }

        public ActionResult Update_Asset_WDV()
        {
            return View();
        }

        public ActionResult Non_IT_Asset_Clearance()
        {
            return View();
        }

        public ActionResult Local_FNA_IOU_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_FNA_IOU_Clearance()
        {
            return View();
        }

        public ActionResult Local_FNA_Loan_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_FNA_Loan_Clearance()
        {
            return View();
        }

        public ActionResult Payroll_Clearance()
        {
            return View();
        }

        public ActionResult Mediclaim_Clearance()
        {
            return View();
        }

        public ActionResult TermLife_Clearance()
        {
            return View();
        }

        public ActionResult Local_HR_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_HR_Clearance_INNOV()
        {
            return View();
        }

        public ActionResult Local_Admin_Bus_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_HR_Clearance()
        {
            return View();
        }

        public ActionResult Update_HOD_FNF()
        {
            return View();
        }

        public ActionResult Petro_Card_Clearance()
        {
            return View();
        }
        public ActionResult Circle_Head_Functional_Reporting_clearance()
        {
            return View();
        }

        public ActionResult Local_Admin_Clearance_GIL()
        {
            return View();
        }

        public ActionResult Corporate_HR_Clearance_Innov_GIL()
        {
            return View();
        }

        public ActionResult Corporate_Petro_Card_Clearance()
        {
            return View();
        }

        public ActionResult Corporate_HR_Clearance_GIL()
        {
            return View();
        }

        public ActionResult Mail_Admin_Clearance()
        {
            return View();
        }

        public ActionResult Support_IT_Clearance()
        {
            return View();
        }

        public ActionResult FNF_Preview()
        {
            return View();
        }

        public ActionResult FNF_All_Preview_GTL()
        {
            return View();
        }

        public ActionResult FNF_Detail_Report()
        {
            return View();
        }

        public ActionResult FNF_Detail_Report_GIL()
        {
            return View();
        }

        public ActionResult HOD_Clearance_Status()
        {
            return View();
        }

        public ActionResult Admin_Clearance_Status()
        {
            return View();
        }

        public ActionResult IT_Clearance_Status()
        {
            return View();
        }

        public ActionResult Asset_Handover_Clearance_Status()
        {
            return View();
        }

        public ActionResult IOU_Clearance_Status()
        {
            return View();
        }

        public ActionResult Loan_Clearance_Status()
        {
            return View();
        }

        public ActionResult Payroll_Clearance_Status()
        {
            return View();
        }

        public ActionResult TermLife_Clearance_Status()
        {
            return View();
        }

        public ActionResult Mediclaim_Clearance_Status()
        {
            return View();
        }

        public ActionResult Non_IT_Clearance_Status()
        {
            return View();
        }


        public ActionResult HR_Clearance_Status()
        {
            return View();
        }


        public ActionResult Admin_Bus_Clearance_Status()
        {
            return View();
        }


        public ActionResult Local_Admin_Clearance_Status()
        {
            return View();
        }


        public ActionResult Local_IOU_Clearance_Status()
        {
            return View();
        }


        public ActionResult Local_IT_Clearance_Status()
        {
            return View();
        }


        public ActionResult Local_Loan_Clearance_Status()
        {
            return View();
        }

        public ActionResult Local_HR_Clearance_Status()
        {
            return View();
        }

        public ActionResult FNF_Status()
        {
            return View();
        }

        public ActionResult Petro_Card_Clearance_Status()
        {
            return View();
        }

        public ActionResult Circle_Head_Clearance_Status()
        {
            return View();
        }

        public ActionResult FNF_Separation_Reason()
        {
           
            return View();
        }

        public ActionResult Mail_Admin_Clearance_Status()
        {
            
            return View();
        }


        public ActionResult Support_IT_Clearance_Status()
        {
         
            return View();
        }



    }
}
