﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class MediclaimController : Controller
    {
       
        public ActionResult Policy_Rate_Master()
        {
            return View();
        }

        public ActionResult Subsidised_Premium_Rate_Chart()
        {
            return View();
        }


        public ActionResult System_Generated_Enrollment_list()
        {
            return View();
        }

        public ActionResult Adhoc_Enrollment_To_Mediclaim_Policy()
        {
            return View();
        }

        public ActionResult Group_Mediclaim_Policy()
        {
            return View();
        }

        public ActionResult Final_Selection_For_Addition_in_Group_Mediclaim_Po()
        {
            return View();
        }

        public ActionResult Delete_Mediclaim()
        {
            return View();
        }

        public ActionResult Mediclaim_Intimation_Of_Hospitalisation()
        {
            return View();
        }

        public ActionResult Claim_Entry_For_Reimbursement()
        {
            return View();
        }

        public ActionResult Mediclaim_Master_Data_Edit()
        {
            return View();
        }

    }
}
