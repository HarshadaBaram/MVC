﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class Expense_AdvanceController : Controller
    {
       
        public ActionResult Raise_New_EA()
        {
            return View();
        }

        public ActionResult Initiate_EA_For_Approval()
        {
            return View();
        }

        public ActionResult EA_Pending_For_Approval()
        {
            return View();
        }

        public ActionResult Approved_EA_List()
        {
            return View();
        }

        public ActionResult EA_Pending_For_Payment()
        {
            return View();
        }

        public ActionResult EA_Documents_Upload()
        {
            return View();
        }

        public ActionResult EA_Bulk_Upload()
        {
            return View();
        }

        public ActionResult Upload_EA_Payment_Details()
        {
            return View();
        }

        public ActionResult Update_EA_Refund_Amount()
        {
            return View();
        }

        public ActionResult EA_Salary_Recovery()
        {
            return View();
        }

        public ActionResult GTL_Conveyance_Payment_Process()
        {
            return View();
        }

        public ActionResult GTL_EA_conveyance_Payment_Process()
        {
            return View();
        }

        public ActionResult Reminder_Mail_Send_For_EA_Balance_Settlement()
        {
            return View();
        }

        public ActionResult Finance_Approval_For_Expense()
        {
            return View();
        }


        public ActionResult EA_Report_User()
        {
            return View();
        }

        public ActionResult Expense_Payble_Receivable_Report()
        {
            return View();
        }

        public ActionResult EA_Staus_Report_View()
        {
            return View();
        }

        public ActionResult EA_Date_Wise_Balance_Report()
        {
            return View();
        }

    }
}
