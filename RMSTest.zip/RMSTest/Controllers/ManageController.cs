﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class ManageController : Controller
    {
       
        public ActionResult Projects()
        {
            return View();
        }

        public ActionResult Circle()
        {
            return View();
        }

        public ActionResult General_Setting()
        {
            return View();
        }

        public ActionResult Offer_Letter()
        {
            return View();
        }

        public ActionResult Category()
        {
            return View();
        }

        public ActionResult Training()
        {
            return View();
        }

        public ActionResult Role()
        {
            return View();
        }

        public ActionResult Report()
        {
            return View();
        }

        public ActionResult Designation()
        {
            return View();
        }

        public ActionResult Training_Type()
        {
            return View();
        }

        public ActionResult Customer()
        {
            return View();
        }

        public ActionResult Project_Role()
        {
            return View();
        }

        public ActionResult Funtional_Department()
        {
            return View();
        }

        public ActionResult Division()
        {
            return View();
        }

        public ActionResult Module()
        {
            return View();
        }

        public ActionResult Create_New_Logins()
        {
            return View();
        }

        public ActionResult Shift()
        {
            return View();
        }

        public ActionResult Country()
        {
            return View();
        }

        public ActionResult Holiday()
        {
            return View();
        }

        public ActionResult Hierarchy()
        {
            return View();
        }

        public ActionResult Hierarchy_Role()
        {
            return View();
        }

        public ActionResult Sub_Department()
        {
            return View();
        }

        public ActionResult Menu()
        {
            return View();
        }

        public ActionResult Location()
        {
            return View();
        }

        public ActionResult Record_Warning_Category()
        {
            return View();
        }

        public ActionResult Vendors()
        {
            return View();
        }

        public ActionResult Import_Holiday()
        {
            return View();
        }

        public ActionResult Resource()
        {
            return View();
        }

        public ActionResult Resource_Status()
        {
            return View();
        }

        public ActionResult Arrears()
        {
            return View();
        }

        


    }
}
