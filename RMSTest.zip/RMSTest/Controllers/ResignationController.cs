﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class ResignationController : Controller
    {
      
        public ActionResult Record_Resignation()
        {
            return View();
        }


        public ActionResult Resource_Deactivation()
        {
            return View();
        }


        public ActionResult Update_Last_Working_Date()
        {
            return View();
        }


        public ActionResult Blacklist_Employee_Mapping()
        {
            return View();
        }


        public ActionResult Remove_From_Blacklist()
        {
            return View();
        }


        public ActionResult Update_Last_Working_Date_GIL()
        {
            return View();
        }


        public ActionResult Resource_Deactivation_Reports()
        {
            return View();
        }


        public ActionResult Record_Resignation_Report()
        {
            return View();
        }


        public ActionResult Blacklist_Employee()
        {
            return View();
        }


        public ActionResult Resignation_Details()
        {
            return View();
        }


        public ActionResult Deactivation_Report_Onrolls()
        {
            return View();
        }


        public ActionResult Deactivation_Pending()
        {
            return View();
        }


    }
}
