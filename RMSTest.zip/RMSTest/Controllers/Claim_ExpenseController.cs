﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RMSTest.Controllers
{
    public class Claim_ExpenseController : Controller
    {
       
        public ActionResult Raise_New_Claim_Expense()
        {
            return View();
        }

        public ActionResult Initiate_Claim_Expense_For_Approval()
        {
            return View();
        }

        public ActionResult Pending_For_Approval()
        {
            return View();
        }

        public ActionResult Documents_Upload()
        {
            return View();
        }

        public ActionResult Approved_Expense_List()
        {
            return View();
        }

        public ActionResult Update_Funding()
        {
            return View();
        }

        public ActionResult Pending_For_Payment()
        {

        return View();

        }

        public ActionResult Upload_Claim_Data_GTL()
        {

            return View();

        }

        public ActionResult Pending_For_Payment_GTL()
        {

            return View();

        }

        public ActionResult GIL_Petty_Cash_Voucher()
        {

            return View();

        }

        public ActionResult Claim_Expense_Reporting_MGR_Approval()
        {

            return View();

        }

        public ActionResult Send_For_Funding()
        {

            return View();

        }

        public ActionResult Claim_Data_Upload()
        {

            return View();

        }

        public ActionResult For_Funding_EPayment()
        {
           
            return View();

        }

        public ActionResult For_Payment()
        {
           
            return View();

        }

        public ActionResult Upload_EPayment_Details()
        {

            return View();

        }

        public ActionResult For_EPayment()
        {

            return View();

        }

        public ActionResult Claim_Expense_Mapping()
        {

            return View();

        }

        public ActionResult GTL_Conveyance_Payment_Process()
        {

            return View();

        }


        public ActionResult GTL_Conveyance_Payment_Upload()
        {

            return View();

        }


        public ActionResult Delete_Claim_Expense_Voucher()
        {

            return View();

        }


        public ActionResult Claim_Expense_Status()
        {

            return View();

        }


        public ActionResult Expense_Report_User()
        {
            
            return View();

        }


        public ActionResult AR_Loader_GTL()
        {
            
            return View();

        }


        public ActionResult Petty_Cash_Details_Report_GIL()
        {
           
            return View();

        }

        public ActionResult Expense_Report_for_Approver()
        {
           
            return View();

        }

        public ActionResult Expense_Report_Rpt_Manager()
        {
          
            return View();

        }



    }
}
